function OnGUI()
{
	if(GUI.Button (Rect (25,25,80,30), "Quit"))
	{
		Application.LoadLevel("mainmenu");	
	}
}


function Update () 
{
}